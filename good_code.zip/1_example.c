#include <stdio.h>
//#include <string.h>
//#include <stdlib.h>
//if you do not use any functionality of some include files, you should not include them  

int main(void)
{
    printf("Hello world\n");
    //return 1; program should return 0 if it works propely
    return 0;
}